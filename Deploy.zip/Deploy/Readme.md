This small program will take care of the Chrome Extensions that make it hard to get to the extension management page in Google Chrome.

It simply goes through the extensions subdirectory and parses the extensions to find out their name and version number and manifest number as well as their location
It lists them in a list box and you can select the one you want to get rid of and remove it.

If you find it useful, a donation is always appreciated:

Donate with this link: paypal.me/GColeJr
Please choose Friends and Family